import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { FaqItem } from "@/lib/types";

interface FAQItemProps {
  faq: FaqItem;
}

export default function FAQItem({ faq }: FAQItemProps) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleOpen = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      <button 
        onClick={toggleOpen}
        className="w-full text-left px-6 py-4 font-medium text-[#36393F] flex justify-between items-center focus:outline-none"
      >
        <span>{faq.question}</span>
        <ChevronDown 
          className={`text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} 
        />
      </button>
      
      {isOpen && (
        <div className="px-6 py-4 border-t border-gray-100">
          <p className="text-gray-600">
            {faq.answer}
          </p>
        </div>
      )}
    </div>
  );
}

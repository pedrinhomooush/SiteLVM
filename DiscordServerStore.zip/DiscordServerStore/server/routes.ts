import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactMessageSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import fetch from "node-fetch";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  
  // Get all server templates
  app.get("/api/server-templates", async (_req: Request, res: Response) => {
    try {
      const templates = await storage.getAllServerTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Error fetching server templates" });
    }
  });
  
  // Get featured server templates
  app.get("/api/server-templates/featured", async (_req: Request, res: Response) => {
    try {
      const templates = await storage.getFeaturedServerTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Error fetching featured server templates" });
    }
  });
  
  // Get server template by ID
  app.get("/api/server-templates/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid server template ID" });
      }
      
      const template = await storage.getServerTemplateById(id);
      if (!template) {
        return res.status(404).json({ message: "Server template not found" });
      }
      
      res.json(template);
    } catch (error) {
      res.status(500).json({ message: "Error fetching server template" });
    }
  });
  
  // Get server templates by type
  app.get("/api/server-templates/type/:type", async (req: Request, res: Response) => {
    try {
      const type = req.params.type;
      const templates = await storage.getServerTemplatesByType(type);
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Error fetching server templates by type" });
    }
  });
  
  // Submit contact form
  app.post("/api/contact", async (req: Request, res: Response) => {
    try {
      const result = insertContactMessageSchema.safeParse(req.body);
      
      if (!result.success) {
        const validationError = fromZodError(result.error);
        return res.status(400).json({ message: validationError.message });
      }
      
      const message = await storage.createContactMessage(result.data);
      
      // Enviar mensagem para o webhook do Discord
      const webhookUrl = "https://discord.com/api/webhooks/1355915034588610682/GDstjLJOfayWErnds a0z44xGL40LyR7lQ6JXKRİNNP6qL-ePieKtWTLyHKfFVvbaIPaQ".replace(/\s+/g, '');
      
      try {
        const discordMessage = {
          embeds: [
            {
              title: "Novo Pedido Personalizado",
              color: 0x5865F2,
              fields: [
                {
                  name: "Nome",
                  value: message.name,
                  inline: true
                },
                {
                  name: "Email",
                  value: message.email,
                  inline: true
                },
                {
                  name: "Usuário do Discord",
                  value: message.discordUsername,
                  inline: true
                },
                {
                  name: "Tipo de Servidor",
                  value: message.serverType,
                  inline: true
                },
                {
                  name: "Requisitos",
                  value: message.requirements || "Nenhum requisito específico"
                }
              ],
              timestamp: new Date().toISOString(),
              footer: {
                text: "Listen Applications - Pedido Personalizado"
              }
            }
          ]
        };
        
        await fetch(webhookUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(discordMessage)
        });
        
        console.log("Mensagem enviada para o webhook do Discord com sucesso");
      } catch (webhookError) {
        console.error("Erro ao enviar mensagem para o webhook do Discord:", webhookError);
        // Continua o fluxo mesmo se houver erro ao enviar para o webhook
      }
      
      res.status(201).json(message);
    } catch (error) {
      console.error("Erro ao enviar mensagem de contato:", error);
      res.status(500).json({ message: "Error submitting contact form" });
    }
  });
  
  // Get all FAQ items
  app.get("/api/faq", async (_req: Request, res: Response) => {
    try {
      const faqItems = await storage.getAllFaqItems();
      res.json(faqItems);
    } catch (error) {
      res.status(500).json({ message: "Error fetching FAQ items" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

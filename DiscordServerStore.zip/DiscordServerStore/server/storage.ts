import { 
  users, 
  type User, 
  type InsertUser,
  serverTemplates,
  type ServerTemplate,
  type InsertServerTemplate,
  contactMessages,
  type ContactMessage,
  type InsertContactMessage,
  faqItems,
  type FaqItem,
  type InsertFaqItem 
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Server template operations
  getAllServerTemplates(): Promise<ServerTemplate[]>;
  getFeaturedServerTemplates(): Promise<ServerTemplate[]>;
  getServerTemplateById(id: number): Promise<ServerTemplate | undefined>;
  getServerTemplatesByType(type: string): Promise<ServerTemplate[]>;
  createServerTemplate(template: InsertServerTemplate): Promise<ServerTemplate>;
  
  // Contact message operations
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  
  // FAQ operations
  getAllFaqItems(): Promise<FaqItem[]>;
  createFaqItem(item: InsertFaqItem): Promise<FaqItem>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private serverTemplates: Map<number, ServerTemplate>;
  private contactMessages: Map<number, ContactMessage>;
  private faqItems: Map<number, FaqItem>;
  
  private currentUserId: number;
  private currentServerTemplateId: number;
  private currentContactMessageId: number;
  private currentFaqItemId: number;

  constructor() {
    this.users = new Map();
    this.serverTemplates = new Map();
    this.contactMessages = new Map();
    this.faqItems = new Map();
    
    this.currentUserId = 1;
    this.currentServerTemplateId = 1;
    this.currentContactMessageId = 1;
    this.currentFaqItemId = 1;
    
    // Initialize with some sample server templates
    this.initializeServerTemplates();
    // Initialize with some sample FAQ items
    this.initializeFaqItems();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Server template operations
  async getAllServerTemplates(): Promise<ServerTemplate[]> {
    return Array.from(this.serverTemplates.values());
  }
  
  async getFeaturedServerTemplates(): Promise<ServerTemplate[]> {
    return Array.from(this.serverTemplates.values()).filter(
      (template) => template.featured
    );
  }
  
  async getServerTemplateById(id: number): Promise<ServerTemplate | undefined> {
    return this.serverTemplates.get(id);
  }
  
  async getServerTemplatesByType(type: string): Promise<ServerTemplate[]> {
    return Array.from(this.serverTemplates.values()).filter(
      (template) => template.type === type
    );
  }
  
  async createServerTemplate(insertTemplate: InsertServerTemplate): Promise<ServerTemplate> {
    const id = this.currentServerTemplateId++;
    // Criamos um objeto que corresponde à definição exata do ServerTemplate
    const template: ServerTemplate = { 
      id,
      name: insertTemplate.name,
      description: insertTemplate.description,
      price: insertTemplate.price,
      discordInviteUrl: insertTemplate.discordInviteUrl,
      imageUrl: insertTemplate.imageUrl,
      type: insertTemplate.type,
      featured: insertTemplate.featured !== undefined ? insertTemplate.featured : false,
      bestseller: insertTemplate.bestseller !== undefined ? insertTemplate.bestseller : false,
      tags: insertTemplate.tags !== undefined ? insertTemplate.tags : []
    };
    this.serverTemplates.set(id, template);
    return template;
  }
  
  // Contact message operations
  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const id = this.currentContactMessageId++;
    const createdAt = new Date().toISOString();
    const message: ContactMessage = { ...insertMessage, id, createdAt };
    this.contactMessages.set(id, message);
    return message;
  }
  
  // FAQ operations
  async getAllFaqItems(): Promise<FaqItem[]> {
    return Array.from(this.faqItems.values()).sort((a, b) => a.order - b.order);
  }
  
  async createFaqItem(insertItem: InsertFaqItem): Promise<FaqItem> {
    const id = this.currentFaqItemId++;
    const item: FaqItem = { ...insertItem, id };
    this.faqItems.set(id, item);
    return item;
  }
  
  // Initialize with sample data
  private initializeServerTemplates() {
    const templates: InsertServerTemplate[] = [
      {
        name: "Servidor de Comunidade",
        description: "Servidor completo para comunidades com canais organizados, bots de moderação e sistema de níveis.",
        price: 19.90,
        discordInviteUrl: "https://discord.gg/example",
        imageUrl: "",
        type: "community",
        featured: true,
        bestseller: false,
        tags: ["Moderação", "Níveis", "Eventos"]
      },
      {
        name: "Servidor de Vendas",
        description: "Servidor otimizado para vendas com bots de pagamento, sistema de tickets e gestão de pedidos.",
        price: 19.99,
        discordInviteUrl: "https://discord.gg/example",
        imageUrl: "",
        type: "sales",
        featured: true,
        bestseller: true,
        tags: ["Vendas", "Tickets", "Pagamentos"]
      },
      {
        name: "Servidor para Jogos",
        description: "Servidor para comunidades de jogos com canais específicos, bots de música e eventos automáticos.",
        price: 17.90,
        discordInviteUrl: "https://discord.gg/example",
        imageUrl: "",
        type: "gaming",
        featured: true,
        bestseller: false,
        tags: ["Jogos", "Música", "Eventos"]
      },
      {
        name: "Servidor Básico",
        description: "Servidor simples com canais básicos para começar sua comunidade.",
        price: 9.90,
        discordInviteUrl: "https://discord.gg/example",
        imageUrl: "",
        type: "basic",
        featured: false,
        bestseller: false,
        tags: ["Básico", "Iniciante"]
      },
      {
        name: "Servidor de Moderação",
        description: "Servidor com bots de moderação configurados e sistema anti-spam.",
        price: 14.90,
        discordInviteUrl: "https://discord.gg/example",
        imageUrl: "",
        type: "moderation",
        featured: false,
        bestseller: false,
        tags: ["Moderação", "Anti-Spam"]
      },
      {
        name: "Servidor para Criadores",
        description: "Ideal para influenciadores e criadores de conteúdo com sistema de anúncios.",
        price: 18.90,
        discordInviteUrl: "https://discord.gg/example",
        imageUrl: "",
        type: "creators",
        featured: false,
        bestseller: false,
        tags: ["Conteúdo", "Anúncios"]
      },
      {
        name: "Servidor para Eventos",
        description: "Servidor com sistema de agendamento de eventos e lembretes automáticos.",
        price: 16.90,
        discordInviteUrl: "https://discord.gg/example",
        imageUrl: "",
        type: "events",
        featured: false,
        bestseller: false,
        tags: ["Eventos", "Calendário"]
      },
      {
        name: "Servidor de Suporte",
        description: "Servidor com sistema de tickets e bot de suporte para atendimento ao cliente.",
        price: 19.50,
        discordInviteUrl: "https://discord.gg/example",
        imageUrl: "",
        type: "support",
        featured: false,
        bestseller: false,
        tags: ["Suporte", "Tickets"]
      }
    ];
    
    templates.forEach((template) => {
      this.createServerTemplate(template);
    });
  }
  
  private initializeFaqItems() {
    const faqs: InsertFaqItem[] = [
      {
        question: "Como recebo meu servidor depois da compra?",
        answer: "Após a confirmação do pagamento, nosso time irá preparar e configurar seu servidor. Você receberá um convite para se tornar o administrador do novo servidor em até 24 horas. Todo o processo é feito diretamente pelo Discord.",
        order: 1
      },
      {
        question: "Posso personalizar os servidores após a compra?",
        answer: "Sim! Todos os nossos servidores são totalmente personalizáveis. Você terá permissões de administrador e poderá modificar qualquer aspecto do servidor conforme sua necessidade. Também oferecemos serviço de personalização adicional caso precise de ajuda.",
        order: 2
      },
      {
        question: "Os bots incluídos são permanentes?",
        answer: "Oferecemos dois tipos de serviço: servidores com bots gratuitos (que são permanentes mas podem ter limitações) e servidores com bots premium (que podem requerer renovação após o período incluído). Todos os detalhes sobre os bots estão especificados na descrição de cada produto.",
        order: 3
      },
      {
        question: "Preciso ter conhecimento técnico para usar os servidores?",
        answer: "Não! Nossos servidores são projetados para serem intuitivos e fáceis de usar. Além disso, fornecemos um guia completo de utilização e estamos disponíveis para suporte técnico caso você tenha alguma dúvida ou dificuldade.",
        order: 4
      },
      {
        question: "Quais formas de pagamento são aceitas?",
        answer: "Aceitamos PIX, transferência bancária, cartões de crédito e débito, boleto e PayPal. Todas as transações são processadas de forma segura através do nosso bot de pagamentos no Discord.",
        order: 5
      }
    ];
    
    faqs.forEach((faq) => {
      this.createFaqItem(faq);
    });
  }
}

import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllServerTemplates(): Promise<ServerTemplate[]> {
    return await db.select().from(serverTemplates);
  }

  async getFeaturedServerTemplates(): Promise<ServerTemplate[]> {
    return await db.select().from(serverTemplates).where(eq(serverTemplates.featured, true));
  }

  async getServerTemplateById(id: number): Promise<ServerTemplate | undefined> {
    const [template] = await db.select().from(serverTemplates).where(eq(serverTemplates.id, id));
    return template;
  }

  async getServerTemplatesByType(type: string): Promise<ServerTemplate[]> {
    return await db.select().from(serverTemplates).where(eq(serverTemplates.type, type));
  }

  async createServerTemplate(insertTemplate: InsertServerTemplate): Promise<ServerTemplate> {
    const [template] = await db
      .insert(serverTemplates)
      .values(insertTemplate)
      .returning();
    return template;
  }

  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const now = new Date().toISOString();
    const [message] = await db
      .insert(contactMessages)
      .values({ ...insertMessage, createdAt: now })
      .returning();
    return message;
  }

  async getAllFaqItems(): Promise<FaqItem[]> {
    return await db.select().from(faqItems).orderBy(faqItems.order);
  }

  async createFaqItem(insertItem: InsertFaqItem): Promise<FaqItem> {
    const [item] = await db
      .insert(faqItems)
      .values(insertItem)
      .returning();
    return item;
  }
}

export const storage = new DatabaseStorage();

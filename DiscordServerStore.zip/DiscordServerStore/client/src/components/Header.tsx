import { FaDiscord } from "react-icons/fa";
import { Button } from "@/components/ui/button";

export default function Header() {
  return (
    <header className="bg-[#0a0a0a] sticky top-0 z-50 border-b border-[#1a1a1a] shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center gap-2">
            <FaDiscord className="h-5 w-5 text-[#5865F2]" />
            <span className="text-white font-bold text-lg">Listen Applications</span>
          </div>
          
          {/* Join Discord Button */}
          <Button 
            className="flex items-center bg-[#5865F2] hover:bg-[#4752c4] text-white text-sm rounded-md shadow-md h-9"
            asChild
          >
            <a href="https://discord.gg/STP68y6hRN" target="_blank" rel="noopener noreferrer">
              <FaDiscord className="mr-2 h-4 w-4" />
              Discord
            </a>
          </Button>
        </div>
      </div>
    </header>
  );
}

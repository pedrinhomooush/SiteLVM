// Common types used in the frontend

export interface ServerTemplate {
  id: number;
  name: string;
  description: string;
  price: number;
  discordInviteUrl: string;
  imageUrl: string;
  type: string;
  featured: boolean;
  bestseller: boolean;
  tags: string[];
}

export interface ContactMessage {
  name: string;
  email: string;
  discordUsername: string;
  serverType: string;
  requirements: string;
}

export interface FaqItem {
  id: number;
  question: string;
  answer: string;
  order: number;
}

export interface ServerFilter {
  type: string;
  priceRange: string;
  features: string;
}

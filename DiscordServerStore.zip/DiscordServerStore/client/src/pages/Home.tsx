import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import MainLayout from "@/layouts/MainLayout";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import FeaturedServerCard from "@/components/FeaturedServerCard";
import FAQItem from "@/components/FAQItem";
import ContactForm from "@/components/ContactForm";
import { ArrowRight } from "lucide-react";
import { FaDiscord } from "react-icons/fa";
import { ServerTemplate, FaqItem } from "@/lib/types";

export default function Home() {
  const [location] = useLocation();
  const { toast } = useToast();

  // Fetch featured server templates
  const { data: featuredServers, isLoading: isLoadingFeatured, error: featuredError } = useQuery<ServerTemplate[]>({
    queryKey: ['/api/server-templates/featured'],
  });

  // Fetch FAQ items
  const { data: faqItems, isLoading: isLoadingFaq, error: faqError } = useQuery<FaqItem[]>({
    queryKey: ['/api/faq'],
  });

  // Handle errors
  useEffect(() => {
    if (featuredError) {
      toast({
        title: "Erro ao carregar servidores em destaque",
        description: "Por favor, tente novamente mais tarde.",
        variant: "destructive",
      });
    }

    if (faqError) {
      toast({
        title: "Erro ao carregar FAQs",
        description: "Por favor, tente novamente mais tarde.",
        variant: "destructive",
      });
    }
  }, [featuredError, faqError, toast]);

  // Handle hash navigation
  useEffect(() => {
    if (location.includes('#')) {
      const id = location.split('#')[1];
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [location]);

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="bg-[#111] text-white py-16 md:py-20 border-b border-[#222]">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center text-center max-w-3xl mx-auto">
            <h1 className="text-3xl md:text-4xl font-medium mb-4 text-gray-200">Servidores Discord Prontos para Usar</h1>
            <p className="text-md md:text-lg mb-8 text-gray-400 max-w-2xl">
              Economize tempo com nossos servidores pré-configurados. Desde modelos simples até servidores completos com bots de moderação, vendas e tickets.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button 
                className="btn-primary"
                asChild
                variant="outline"
              >
                <Link href="/catalog">
                  <a>Ver Catálogo</a>
                </Link>
              </Button>
              <Button 
                className="bg-[#1a1a1a] hover:bg-[#252525] text-gray-300 border border-[#333]"
                variant="outline"
                asChild
              >
                <Link href="#contact">
                  <a>Solicitar Personalizado</a>
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Servers Section */}
      <section id="featured" className="py-12 bg-[#0D0D0D] border-y border-[#222]">
        <div className="container mx-auto px-4">
          <h2 className="section-title text-center">Servidores em Destaque</h2>
          <p className="section-subtitle text-center">Nossos modelos mais populares prontos para você utilizar</p>
          
          {isLoadingFeatured ? (
            <div className="servers-scroll">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="w-80 h-96 bg-[#111] animate-pulse rounded-lg border border-[#222]"></div>
              ))}
            </div>
          ) : (
            <div className="servers-scroll">
              {featuredServers?.map((server) => (
                <div key={server.id} className="w-80">
                  <FeaturedServerCard server={server} />
                </div>
              ))}
            </div>
          )}
          
          <div className="text-center mt-10">
            <Button 
              className="btn-secondary"
              asChild
            >
              <Link href="/catalog">
                <a>Ver Todos os Servidores</a>
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-[#111]">
        <div className="container mx-auto px-4">
          <h2 className="section-title text-center">Como Funciona</h2>
          <p className="section-subtitle text-center">Processo simples para adquirir seu servidor Discord personalizado</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="text-center bg-[#161616] p-6 rounded-lg border border-[#222]">
              <div className="bg-[#5865F2] bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center text-[#5865F2] text-2xl font-medium mx-auto mb-4">1</div>
              <h3 className="text-lg font-medium mb-2 text-gray-200">Escolha seu Servidor</h3>
              <p className="text-gray-400 text-sm">Navegue pelo nosso catálogo e encontre o modelo de servidor que melhor atenda às suas necessidades.</p>
            </div>
            
            {/* Step 2 */}
            <div className="text-center bg-[#161616] p-6 rounded-lg border border-[#222]">
              <div className="bg-[#5865F2] bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center text-[#5865F2] text-2xl font-medium mx-auto mb-4">2</div>
              <h3 className="text-lg font-medium mb-2 text-gray-200">Entre no Discord</h3>
              <p className="text-gray-400 text-sm">Clique no botão "Comprar no Discord" para ser redirecionado ao nosso servidor oficial no Discord.</p>
            </div>
            
            {/* Step 3 */}
            <div className="text-center bg-[#161616] p-6 rounded-lg border border-[#222]">
              <div className="bg-[#5865F2] bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center text-[#5865F2] text-2xl font-medium mx-auto mb-4">3</div>
              <h3 className="text-lg font-medium mb-2 text-gray-200">Receba seu Servidor</h3>
              <p className="text-gray-400 text-sm">Após o pagamento, nosso time irá configurar e entregar seu servidor pronto para uso em até 24 horas.</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-16 bg-[#0D0D0D] border-y border-[#222]">
        <div className="container mx-auto px-4">
          <h2 className="section-title text-center">Perguntas Frequentes</h2>
          <p className="section-subtitle text-center">Tire suas dúvidas sobre nossos servidores Discord</p>
          
          <div className="max-w-3xl mx-auto space-y-4">
            {isLoadingFaq ? (
              // Loading skeleton
              <>
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="h-20 bg-[#111] animate-pulse rounded-lg border border-[#222]"></div>
                ))}
              </>
            ) : (
              // Actual FAQ items
              <>
                {faqItems?.map((faq) => (
                  <FAQItem key={faq.id} faq={faq} />
                ))}
              </>
            )}
          </div>
          
          <div className="text-center mt-10">
            <Button 
              variant="link" 
              className="inline-flex items-center text-[#5865F2] hover:text-[#4752c4] font-medium transition"
            >
              Ver todas as perguntas frequentes <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>

      {/* Contact Form Section */}
      <section id="contact" className="py-16 bg-[#111]">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="section-title text-center">Solicite um Servidor Personalizado</h2>
            <p className="section-subtitle text-center">Não encontrou o que procura? Crie um servidor totalmente personalizado para suas necessidades</p>
            
            <div className="bg-[#161616] p-8 rounded-lg border border-[#222]">
              <ContactForm />
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}

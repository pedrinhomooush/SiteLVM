import { FaDiscord } from "react-icons/fa";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ServerTemplate } from "@/lib/types";

interface ServerCardProps {
  server: ServerTemplate;
}

export default function ServerCard({ server }: ServerCardProps) {
  // Função para formatar o preço em reais
  const formatPrice = (price: number) => {
    return (price / 100).toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 2
    });
  };

  return (
    <Card className="server-card h-full hover:scale-[1.02] transition-all duration-200">
      <CardContent className="p-5 flex flex-col h-full">
        {server.bestseller && (
          <div className="mb-2">
            <Badge className="text-[10px] bg-[#5865F2] text-white py-0 px-2 h-5 uppercase rounded-full">
              Mais vendido
            </Badge>
          </div>
        )}
        
        <div className="flex justify-between items-start mb-3">
          <h3 className="text-white text-lg font-bold">{server.name}</h3>
          <span className="text-[#5865F2] font-bold text-lg">
            {formatPrice(server.price)}
          </span>
        </div>
        
        <p className="text-gray-400 text-sm mb-4 leading-relaxed flex-grow">
          {server.description.length > 100 
            ? `${server.description.substring(0, 100)}...` 
            : server.description}
        </p>
        
        <div className="flex flex-wrap gap-1.5 mb-4">
          {server.tags.map((tag, index) => (
            <Badge 
              key={index} 
              variant="outline" 
              className="text-[10px] bg-[#111] border-[#222] text-gray-300 py-0 px-2 h-5 rounded-full"
            >
              {tag}
            </Badge>
          ))}
        </div>
        
        <div className="mt-auto">
          <Button 
            className="w-full bg-[#5865F2] hover:bg-[#4752c4] text-white font-medium text-sm h-9 rounded-md shadow-sm"
            asChild
          >
            <a href={server.discordInviteUrl} target="_blank" rel="noopener noreferrer">
              <FaDiscord className="mr-2 h-4 w-4" />
              Adquirir no Discord
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

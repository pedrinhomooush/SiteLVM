import { db } from "../server/db";
import { serverTemplates, faqItems } from "../shared/schema";

async function seed() {
  console.log("Seeding database...");

  // Add server templates
  const serverTemplatesData = [
    {
      name: "Servidor Básico",
      description: "Um servidor simples com canais de texto e voz, perfeito para pequenas comunidades.",
      price: 1000, // R$ 10.00
      discordInviteUrl: "https://discord.gg/STP68y6hRN",
      imageUrl: "",
      type: "basic",
      featured: true,
      bestseller: true,
      tags: ["5 canais", "Básico", "Rápido"],
    },
    {
      name: "Servidor de Comunidade",
      description: "Servidor completo com sistema de níveis, bots de moderação e canais organizados.",
      price: 1500, // R$ 15.00
      discordInviteUrl: "https://discord.gg/STP68y6hRN",
      imageUrl: "",
      type: "community",
      featured: true,
      bestseller: false,
      tags: ["Moderação", "Sistema de níveis", "Roles personalizadas"],
    },
    {
      name: "Servidor Premium",
      description: "Servidor de alta qualidade com múltiplos bots personalizados, sistema avançado de tickets e painéis exclusivos.",
      price: 2000, // R$ 20.00
      discordInviteUrl: "https://discord.gg/STP68y6hRN",
      imageUrl: "",
      type: "premium",
      featured: true,
      bestseller: false,
      tags: ["Premium", "Bots personalizados", "Suporte prioritário"],
    },
    {
      name: "Servidor para Vendas",
      description: "Servidor com bots de vendas, sistema de tickets e canais organizados para produtos.",
      price: 1800, // R$ 18.00
      discordInviteUrl: "https://discord.gg/STP68y6hRN",
      imageUrl: "",
      type: "sales",
      featured: true,
      bestseller: false,
      tags: ["Sistema de vendas", "Tickets", "Categorias de produtos"],
    },
    {
      name: "Servidor Gaming",
      description: "Servidor para comunidades de jogos com canais para diferentes jogos e bots de estatísticas.",
      price: 1200, // R$ 12.00
      discordInviteUrl: "https://discord.gg/STP68y6hRN",
      imageUrl: "",
      type: "gaming",
      featured: false,
      bestseller: false,
      tags: ["Gaming", "Estatísticas", "LFG"],
    },
    {
      name: "Servidor Educacional",
      description: "Ideal para grupos de estudo, com canais para diferentes matérias e bots para organizar horários.",
      price: 1000, // R$ 10.00
      discordInviteUrl: "https://discord.gg/STP68y6hRN",
      imageUrl: "",
      type: "education",
      featured: false,
      bestseller: false,
      tags: ["Educação", "Organização", "Estudos"],
    },
  ];

  // Add FAQ items
  const faqItemsData = [
    {
      question: "Como funciona o processo de compra?",
      answer: "Após selecionar o servidor desejado, você será redirecionado para o nosso Discord oficial. Lá, um de nossos atendentes irá finalizar sua compra e configurar seu servidor em até 24 horas.",
      order: 1,
    },
    {
      question: "Posso solicitar personalização no servidor?",
      answer: "Sim! Todos os nossos servidores podem ser personalizados. Se precisar de recursos adicionais, basta solicitar ao realizar a compra ou através do formulário de contato.",
      order: 2,
    },
    {
      question: "Quais métodos de pagamento são aceitos?",
      answer: "Aceitamos PIX, transferência bancária, boleto e cartão de crédito. O pagamento é processado através de nosso atendente no Discord.",
      order: 3,
    },
    {
      question: "Quanto tempo leva para receber meu servidor?",
      answer: "Após a confirmação do pagamento, seu servidor será configurado e entregue em até 24 horas úteis.",
      order: 4,
    },
    {
      question: "Oferecem suporte após a entrega do servidor?",
      answer: "Sim, oferecemos suporte técnico gratuito por 30 dias após a entrega do servidor. Após esse período, oferecemos pacotes de suporte contínuo.",
      order: 5,
    },
  ];

  try {
    // Insert server templates
    console.log("Inserting server templates...");
    await db.insert(serverTemplates).values(serverTemplatesData);
    
    // Insert FAQ items
    console.log("Inserting FAQ items...");
    await db.insert(faqItems).values(faqItemsData);
    
    console.log("Database seeded successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    process.exit(0);
  });
import { FaDiscord } from "react-icons/fa";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function ContactForm() {
  return (
    <Card className="border border-[#1a1a1a] bg-[#0d0d0d] shadow-md rounded-md p-1">
      <CardContent className="flex flex-col items-center justify-center py-10 px-4 text-center">
        <FaDiscord className="h-16 w-16 text-[#5865F2] mb-6" />
        
        <h3 className="text-2xl font-bold text-white mb-4">Precisa de um servidor personalizado?</h3>
        
        <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto">
          Entre no nosso servidor do Discord para conversar diretamente com nossa equipe e solicitar um orçamento para seu projeto personalizado.
        </p>

        <Button 
          className="bg-[#5865F2] hover:bg-[#4752c4] text-white font-medium text-base py-6 px-8 h-auto rounded-md shadow-md"
          asChild
        >
          <a href="https://discord.gg/STP68y6hRN" target="_blank" rel="noopener noreferrer">
            <FaDiscord className="mr-3 h-5 w-5" />
            Entrar no Discord
          </a>
        </Button>
        
        <p className="text-gray-500 text-sm mt-6">
          Nossa equipe está pronta para atendê-lo e criar a solução perfeita para suas necessidades.
        </p>
      </CardContent>
    </Card>
  );
}

import { useEffect } from "react";
import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import MainLayout from "@/layouts/MainLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, ArrowLeft, CheckCircle2 } from "lucide-react";
import { FaDiscord } from "react-icons/fa";
import { ServerTemplate } from "@/lib/types";

export default function ServerDetails() {
  const { id } = useParams();
  const { toast } = useToast();
  
  const { 
    data: server, 
    isLoading, 
    error 
  } = useQuery<ServerTemplate>({
    queryKey: [`/api/server-templates/${id}`],
  });
  
  useEffect(() => {
    if (error) {
      toast({
        title: "Erro ao carregar detalhes do servidor",
        description: "Por favor, tente novamente mais tarde.",
        variant: "destructive",
      });
    }
  }, [error, toast]);

  if (isLoading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-16">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
            <div className="h-80 bg-gray-200 rounded mb-6"></div>
            <div className="h-6 bg-gray-200 rounded w-1/2 mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-full mb-4"></div>
            <div className="h-4 bg-gray-200 rounded w-full mb-4"></div>
            <div className="flex space-x-2 mb-4">
              <div className="h-6 bg-gray-200 rounded w-16"></div>
              <div className="h-6 bg-gray-200 rounded w-16"></div>
            </div>
            <div className="h-10 bg-gray-200 rounded w-full"></div>
          </div>
        </div>
      </MainLayout>
    );
  }

  if (!server) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-16 flex flex-col items-center justify-center">
          <AlertCircle className="h-16 w-16 text-red-500 mb-4" />
          <h1 className="text-2xl font-bold mb-2">Servidor não encontrado</h1>
          <p className="text-gray-600 mb-6">O servidor que você está procurando não existe ou foi removido.</p>
          <Button asChild>
            <Link href="/catalog">
              <a className="flex items-center">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Voltar para o catálogo
              </a>
            </Link>
          </Button>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-12">
        <Button variant="outline" asChild className="mb-6">
          <Link href="/catalog">
            <a className="flex items-center">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar para o catálogo
            </a>
          </Link>
        </Button>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Server Image */}
          <div className="bg-gray-100 rounded-lg overflow-hidden">
            <img 
              src={server.imageUrl} 
              alt={server.name}
              className="w-full h-full object-cover"
            />
          </div>
          
          {/* Server Details */}
          <div>
            <div className="flex justify-between items-start mb-4">
              <h1 className="text-3xl font-bold">{server.name}</h1>
              <div className="text-2xl font-bold text-[#5865F2]">R$ {server.price}</div>
            </div>
            
            <div className="flex flex-wrap gap-2 mb-4">
              {server.tags.map((tag, index) => (
                <Badge key={index} variant="discord" className="px-2 py-1">
                  {tag}
                </Badge>
              ))}
            </div>
            
            <div className="mb-6 text-gray-700">
              <p className="text-lg mb-4">{server.description}</p>
            </div>
            
            <Button 
              className="w-full bg-[#5865F2] hover:bg-opacity-80 text-white text-center py-3 rounded-md font-medium transition mb-6"
              size="lg"
              asChild
            >
              <a href={server.discordInviteUrl} target="_blank" rel="noopener noreferrer">
                <FaDiscord className="mr-2 h-5 w-5" />
                Comprar no Discord
              </a>
            </Button>
            
            <Separator className="my-6" />
            
            {/* Features */}
            <Card>
              <CardHeader>
                <CardTitle>Características do Servidor</CardTitle>
                <CardDescription>
                  Tudo o que está incluído neste modelo de servidor
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {server.tags.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <CheckCircle2 className="h-5 w-5 text-[#57F287] mr-2" />
                      <span>{feature}</span>
                    </li>
                  ))}
                  <li className="flex items-center">
                    <CheckCircle2 className="h-5 w-5 text-[#57F287] mr-2" />
                    <span>Permissões de administrador</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle2 className="h-5 w-5 text-[#57F287] mr-2" />
                    <span>Suporte técnico por 30 dias</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle2 className="h-5 w-5 text-[#57F287] mr-2" />
                    <span>Entrega em até 24 horas</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}

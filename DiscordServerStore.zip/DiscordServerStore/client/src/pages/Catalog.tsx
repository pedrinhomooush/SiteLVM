import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import MainLayout from "@/layouts/MainLayout";
import ServerCard from "@/components/ServerCard";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { ServerTemplate, ServerFilter } from "@/lib/types";
import ContactForm from "@/components/ContactForm";

export default function Catalog() {
  const { toast } = useToast();
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState<ServerFilter>({
    type: "",
    priceRange: "",
    features: "",
  });
  
  const { 
    data: allServers, 
    isLoading, 
    error 
  } = useQuery<ServerTemplate[]>({
    queryKey: ['/api/server-templates'],
  });
  
  useEffect(() => {
    if (error) {
      toast({
        title: "Erro ao carregar servidores",
        description: "Por favor, tente novamente mais tarde.",
        variant: "destructive",
      });
    }
  }, [error, toast]);

  // Apply filters to servers
  const filteredServers = allServers ? allServers.filter((server) => {
    let matchesType = true;
    let matchesPriceRange = true;
    let matchesFeatures = true;
    
    // Filter by type
    if (filters.type && filters.type !== "") {
      matchesType = server.type === filters.type;
    }
    
    // Filter by price range
    if (filters.priceRange && filters.priceRange !== "") {
      const [min, max] = filters.priceRange.split("-").map(Number);
      if (max) {
        matchesPriceRange = server.price >= min && server.price <= max;
      } else {
        // For "200+" range
        matchesPriceRange = server.price >= min;
      }
    }
    
    // Filter by features
    if (filters.features && filters.features !== "") {
      matchesFeatures = server.tags.includes(filters.features);
    }
    
    return matchesType && matchesPriceRange && matchesFeatures;
  }) : [];

  // Pagination logic
  const serversPerPage = 8;
  const totalPages = Math.ceil((filteredServers?.length || 0) / serversPerPage);
  const paginatedServers = filteredServers?.slice(
    (currentPage - 1) * serversPerPage,
    currentPage * serversPerPage
  );

  // Handle filter changes
  const handleFilterChange = (field: keyof ServerFilter, value: string) => {
    setFilters({
      ...filters,
      [field]: value,
    });
    setCurrentPage(1); // Reset to first page when filters change
  };

  // Reset all filters
  const resetFilters = () => {
    setFilters({
      type: "",
      priceRange: "",
      features: "",
    });
    setCurrentPage(1);
  };

  return (
    <MainLayout>
      <section className="py-16 bg-[#121212]">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold mb-2 text-center text-white">Modelos de Servidores Discord</h2>
          <p className="text-gray-400 text-center mb-10">Escolha o servidor perfeito para suas necessidades</p>
          
          {/* Filters */}
          <div className="mb-10 bg-[#0d0d0d] p-6 rounded-md shadow-md border border-[#1a1a1a]">
            <h3 className="text-xl font-bold mb-4 text-white">Filtros</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <Label className="block text-sm font-medium text-gray-300 mb-1">Tipo de Servidor</Label>
                <Select 
                  value={filters.type} 
                  onValueChange={(value) => handleFilterChange("type", value)}
                >
                  <SelectTrigger className="bg-[#181818] border-[#333] text-gray-200">
                    <SelectValue placeholder="Todos os tipos" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#181818] border-[#333]">
                    <SelectItem value="all-types">Todos os tipos</SelectItem>
                    <SelectItem value="community">Comunidade</SelectItem>
                    <SelectItem value="sales">Vendas</SelectItem>
                    <SelectItem value="gaming">Jogos</SelectItem>
                    <SelectItem value="education">Educação</SelectItem>
                    <SelectItem value="support">Suporte</SelectItem>
                    <SelectItem value="events">Eventos</SelectItem>
                    <SelectItem value="moderation">Moderação</SelectItem>
                    <SelectItem value="basic">Básico</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="block text-sm font-medium text-gray-300 mb-1">Faixa de Preço</Label>
                <Select 
                  value={filters.priceRange} 
                  onValueChange={(value) => handleFilterChange("priceRange", value)}
                >
                  <SelectTrigger className="bg-[#181818] border-[#333] text-gray-200">
                    <SelectValue placeholder="Qualquer preço" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#181818] border-[#333]">
                    <SelectItem value="any-price">Qualquer preço</SelectItem>
                    <SelectItem value="0-50">Até R$ 50</SelectItem>
                    <SelectItem value="50-100">R$ 50 - R$ 100</SelectItem>
                    <SelectItem value="100-200">R$ 100 - R$ 200</SelectItem>
                    <SelectItem value="200+">Acima de R$ 200</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="block text-sm font-medium text-gray-300 mb-1">Recursos</Label>
                <Select 
                  value={filters.features} 
                  onValueChange={(value) => handleFilterChange("features", value)}
                >
                  <SelectTrigger className="bg-[#181818] border-[#333] text-gray-200">
                    <SelectValue placeholder="Todos os recursos" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#181818] border-[#333]">
                    <SelectItem value="all-features">Todos os recursos</SelectItem>
                    <SelectItem value="Moderação">Moderação</SelectItem>
                    <SelectItem value="Tickets">Sistema de Tickets</SelectItem>
                    <SelectItem value="Música">Bot de Música</SelectItem>
                    <SelectItem value="Níveis">Sistema de Níveis</SelectItem>
                    <SelectItem value="Eventos">Eventos</SelectItem>
                    <SelectItem value="Vendas">Vendas</SelectItem>
                    <SelectItem value="Suporte">Suporte</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-end space-x-2">
                <Button 
                  className="w-full bg-[#5865F2] hover:bg-[#4752c4] text-white"
                  onClick={resetFilters}
                >
                  Limpar Filtros
                </Button>
              </div>
            </div>
          </div>
          
          {/* Server Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                <div key={i} className="h-80 bg-[#181818] animate-pulse rounded-md"></div>
              ))}
            </div>
          ) : paginatedServers?.length === 0 ? (
            <div className="text-center py-12 bg-[#0d0d0d] rounded-md border border-[#1a1a1a] p-8">
              <h3 className="text-xl font-medium mb-2 text-white">Nenhum servidor encontrado</h3>
              <p className="text-gray-400 mb-4">Tente ajustar seus filtros ou visualize todos os servidores</p>
              <Button
                className="bg-[#5865F2] hover:bg-[#4752c4] text-white"
                onClick={resetFilters}
              >
                Ver Todos os Servidores
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {paginatedServers?.map((server) => (
                <ServerCard key={server.id} server={server} />
              ))}
            </div>
          )}
          
          {/* Pagination */}
          {filteredServers?.length > serversPerPage && (
            <div className="mt-10 flex justify-center">
              <nav className="inline-flex rounded-md shadow-md">
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                  className="rounded-l-md border border-[#333] bg-[#181818] text-gray-300 hover:bg-[#222]"
                >
                  <ChevronLeft className="h-4 w-4" />
                  <span className="sr-only">Anterior</span>
                </Button>
                
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                  <Button
                    key={page}
                    variant={currentPage === page ? "default" : "outline"}
                    onClick={() => setCurrentPage(page)}
                    className={`${
                      currentPage === page 
                        ? "bg-[#5865F2] text-white" 
                        : "bg-[#181818] text-gray-300 hover:bg-[#222] border-[#333]"
                    } px-4 py-2 text-sm font-medium border`}
                  >
                    {page}
                  </Button>
                ))}
                
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                  className="rounded-r-md border border-[#333] bg-[#181818] text-gray-300 hover:bg-[#222]"
                >
                  <ChevronRight className="h-4 w-4" />
                  <span className="sr-only">Próximo</span>
                </Button>
              </nav>
            </div>
          )}
          
          {/* Contact Section */}
          <div className="mt-20">
            <ContactForm />
          </div>
        </div>
      </section>
    </MainLayout>
  );
}

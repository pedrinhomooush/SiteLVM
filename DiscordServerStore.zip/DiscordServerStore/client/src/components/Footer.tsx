import { FaDiscord } from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="bg-[#0a0a0a] text-gray-400 py-6 border-t border-[#1a1a1a]">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center justify-center">
          <div className="flex items-center gap-2 mb-4">
            <FaDiscord className="h-5 w-5 text-[#5865F2]" />
            <span className="font-bold text-white text-base">Listen Applications</span>
          </div>
          <p className="text-gray-500 text-sm mb-4 text-center max-w-md">
            Servidores Discord profissionais e personalizados para sua comunidade.
          </p>
          <div className="flex justify-center mb-6">
            <a 
              href="https://discord.gg/STP68y6hRN" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="bg-[#5865F2] hover:bg-[#4752c4] text-white px-4 py-2 rounded-md text-sm inline-flex items-center transition-colors duration-200"
            >
              <FaDiscord className="mr-2 h-4 w-4" />
              Junte-se ao nosso Discord
            </a>
          </div>
          
          <div className="border-t border-[#1a1a1a] w-full mt-2 pt-4 flex flex-col items-center">
            <p className="text-gray-500 text-xs mb-1">
              &copy; {new Date().getFullYear()} Listen Applications. Todos os direitos reservados.
            </p>
            <p className="text-gray-600 text-xs">
              Discord é uma marca registrada de Discord Inc. Não somos afiliados ao Discord.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
